To view this project, run the coursework.exe file inside the build folder.
There are no additional cameras or controls.

Video Demo:
https://drive.google.com/file/d/1Chcd4END3usoMLMdGkazQBjCGPwbQ-Gy/view?usp=sharing