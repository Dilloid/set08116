To view this project, run the coursework.exe file inside the build folder.
There are no additional cameras or controls.